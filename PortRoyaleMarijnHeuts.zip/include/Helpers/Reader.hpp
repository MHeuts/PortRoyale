//
// Created by Marijn Heuts on 10/01/2019.
//

#ifndef PORTROYALE_READER_HPP
#define PORTROYALE_READER_HPP

#include <fstream>

class Reader{
public:
    ReadShips(){
        std::ifstream stream("schepen.csv");
        String ling;
        stream.getline()
    }
};
#endif //PORTROYALE_READER_HPP
