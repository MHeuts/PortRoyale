//
// Created by Marijn Heuts on 21/12/2018.
//

#ifndef PORTROYALE_GOODSTYPE_HPP
#define PORTROYALE_GOODSTYPE_HPP

enum GoodsType{
    bakstenen,
    laken,
    cacao,
    katoen,
    verfstof,
    vis,
    hennep,
    aardappels,
    rum,
    zout,
    suiker,
    tabak,
    graan,
    vlees,
    hout
};

#endif //PORTROYALE_GOODSTYPE_HPP
