//
// Created by Marijn Heuts on 21/12/2018.
//

#ifndef PORTROYALE_ENEMY_HPP
#define PORTROYALE_ENEMY_HPP


class Enemy {

};


#endif //PORTROYALE_ENEMY_HPP
