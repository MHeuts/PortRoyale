//
// Created by Marijn Heuts on 21/12/2018.
//

#ifndef PORTROYALE_HARBOURNAME_HPP
#define PORTROYALE_HARBOURNAME_HPP

enum HarbourName {
    Roatan,
    Belize,
    Cayman,
    Evangelista,
    Trinidad,
    Port_Royale,
    Santiago,
    Port_au_prince,
    Santo_Domingo,
    Saint_Kitts,
    Santa_Lucia,
    Grenada,
    Port_of_Spain,
    Puerto_Santo,
    Margarita,
    Caracas,
    Puerto_Cabello,
    Curacao,
    Coro,
    Gibraltar,
    Maracaibo,
    Santa_Marta,
    Cartagena,
    Providence
};

#endif //PORTROYALE_HARBOURNAME_HPP
