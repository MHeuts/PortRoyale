//
// Created by Marijn Heuts on 14/01/2019.
//

#ifndef PORTROYALE_GOODS_HPP
#define PORTROYALE_GOODS_HPP

#endif //PORTROYALE_GOODS_HPP

class Goods{
private:
    String name;
    int minAmount;
    int maxAmount;
    int ammount;
    int price;
    int minPrice;
    int maxPrice;
};