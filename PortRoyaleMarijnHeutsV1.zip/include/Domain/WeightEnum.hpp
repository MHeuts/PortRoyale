//
// Created by Marijn Heuts on 11/01/2019.
//

#ifndef PORTROYALE_WEIGHTENUM_HPP
#define PORTROYALE_WEIGHTENUM_HPP
enum WeightEnum{
    Light,
    Normal,
    Heavy
};
#endif //PORTROYALE_WEIGHTENUM_HPP
