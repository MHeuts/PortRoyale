//
// Created by Marijn Heuts on 11/01/2019.
//

#ifndef PORTROYALE_MAP_HPP
#define PORTROYALE_MAP_HPP

template <typename T>
class Map{

};
#endif //PORTROYALE_MAP_HPP
